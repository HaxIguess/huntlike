package com.huntlike.client.screen;

import java.util.List;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

import com.huntlike.HuntLike;
import com.huntlike.client.ClientHuntState;
import com.huntlike.hunt.HuntData;
import com.huntlike.network.HuntPayloads;
import com.huntlike.nexus.SoulNexus;

/**
 * The Soul Nexus: your soul in the middle of a triangle with Health, Defense and Damage in the corners. Attack (left-click)
 * on a corner adds a point, use (right-click) takes one back, like the Paths; Shift does 10. The cyan shape inside shows where the points are.
 */
public class SoulNexusScreen extends Screen {
	private static final int W = 300;
	private static final int H = 212;
	private static final int RADIUS = 58;
	private static final int CORNER_W = 32;
	private static final int CORNER_H = 28;
	private static final int CYAN = 0xFF55FFFF;
	private static final int DIM = 0xFF3A6A78;
	private static final int WHITE = 0xFFFFFFFF;
	private static final int GRAY = 0xFFAAAAAA;
	private static final String[] CORNERS = {SoulNexus.HEALTH, SoulNexus.DEFENSE, SoulNexus.DAMAGE};
	private static final String[] NAMES = {"Health", "Defense", "Damage"};
	/** Heart, shield and crossed swords. */
	private static final String[] SYMBOLS = {"\u2764", "\u26E8", "\u2694"};
	private static final int[] COLORS = {0xFFFF5555, 0xFF55AAFF, 0xFFFFAA00};

	private int left;
	private int top;
	private int cx;
	private int cy;

	public SoulNexusScreen() {
		super(Component.literal("Soul Nexus"));
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	/** Corner i's point of the triangle: Health on top, Defense bottom left, Damage bottom right. */
	private double[] vertex(int i, double scale) {
		double angle = Math.toRadians(-90 + 120 * (i == 0 ? 0 : i == 1 ? 2 : 1));
		return new double[] {cx + Math.cos(angle) * RADIUS * scale, cy + Math.sin(angle) * RADIUS * scale};
	}

	/** The corner button's box: x, y, w, h. */
	private int[] box(int i) {
		double[] v = vertex(i, 1.0);
		int x = (int) v[0] - CORNER_W / 2;
		int y = i == 0 ? (int) v[1] - CORNER_H - 2 : (int) v[1] + 4;
		if (i == 1) {
			x = Math.max(left + 8, x - 10);
		} else if (i == 2) {
			x = Math.min(left + W - 8 - CORNER_W, x + 10);
		}
		return new int[] {x, y, CORNER_W, CORNER_H};
	}

	private static boolean inside(int[] box, double x, double y) {
		return x >= box[0] && x < box[0] + box[2] && y >= box[1] && y < box[1] + box[3];
	}

	private boolean overSoul(double x, double y) {
		return Math.hypot(x - cx, y - cy) <= 12;
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		super.extractRenderState(g, mouseX, mouseY, delta);
		HuntData data = ClientHuntState.data;
		left = (this.width - W) / 2;
		top = (this.height - H) / 2;
		cx = left + W / 2;
		// The triangle's height (soul included) is centered in the window's content area.
		cy = top + 126;
		g.blitSprite(RenderPipelines.GUI_TEXTURED, HuntLike.id("menu/window"), left, top, W, H);
		Component title = Component.literal("Soul Nexus").withStyle(style -> style.withBold(true)).withColor(0x404040);
		g.text(this.font, title, cx - this.font.width(title) / 2, top + 7, 0xFF404040, false);
		g.blitSprite(RenderPipelines.GUI_TEXTURED, HuntLike.id("menu/content"), left + 6, top + 18, W - 12, H - 24);
		// The same darkened, drifting end portal starfield as the Paths.
		PathsScreen.drawStarfield(g, left + 8, top + 20, left + W - 8, top + H - 8, 0, 0);

		// The triangle, then the cyan shape of the points spent (each corner's share of the cap).
		for (int i = 0; i < 3; i++) {
			line(g, vertex(i, 1.0), vertex((i + 1) % 3, 1.0), DIM, 2);
			line(g, vertex(i, 0.0), vertex(i, 1.0), 0xFF24434C, 1);
		}
		double[][] shape = new double[3][];
		for (int i = 0; i < 3; i++) {
			shape[i] = vertex(i, Math.max(0.06, SoulNexus.get(data, CORNERS[i]) / (double) SoulNexus.CAP));
		}
		for (int i = 0; i < 3; i++) {
			line(g, shape[i], shape[(i + 1) % 3], CYAN, 2);
		}

		// The soul: a glowing orb that slowly pulses.
		double pulse = 0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 400.0);
		drawOrb(g, cx, cy, 11 + (int) Math.round(pulse * 2), 0x2255FFFF);
		drawOrb(g, cx, cy, 9, 0x6655FFFF);
		drawOrb(g, cx, cy, 7, 0xFF55FFFF);
		drawOrb(g, cx, cy, 4, 0xFFCCFFFF);
		drawOrb(g, cx - 2, cy - 2, 1, 0xFFFFFFFF);

		for (int i = 0; i < 3; i++) {
			int[] b = box(i);
			boolean hover = inside(b, mouseX, mouseY);
			g.blitSprite(RenderPipelines.GUI_TEXTURED, HuntLike.id(hover ? "menu/panel" : "menu/panel_dark"), b[0], b[1], b[2], b[3]);
			int points = SoulNexus.get(data, CORNERS[i]);
			// The symbol: a heart, a shield or a sword; then the points.
			int sy = b[1] + 3;
			// The symbol, drawn as a text character at double size: a heart, a shield or crossed swords.
			Component symbol = Component.literal(SYMBOLS[i]).withColor(COLORS[i] & 0xFFFFFF);
			var pose = g.pose();
			pose.pushMatrix();
			pose.translate(b[0] + b[2] / 2.0F, sy);
			pose.scale(1.5F, 1.5F);
			g.text(this.font, symbol, -this.font.width(symbol) / 2, 0, WHITE, true);
			pose.popMatrix();
			g.centeredText(this.font, Component.literal(points + "/" + SoulNexus.CAP).withColor(points >= SoulNexus.CAP ? 0xFFAA00 : 0xFFFFFF),
					b[0] + b[2] / 2, b[1] + 18, WHITE);
			if (hover) {
				g.setTooltipForNextFrame(this.font, List.of(Component.literal(NAMES[i]).withColor(COLORS[i] & 0xFFFFFF),
						Component.literal(points + "/" + SoulNexus.CAP).withColor(0xFFFFFF),
						Component.literal(effect(i, points)).withColor(0x55FFFF)), java.util.Optional.empty(), mouseX, mouseY);
			}
		}
		if (overSoul(mouseX, mouseY)) {
			g.setTooltipForNextFrame(this.font, List.of(Component.literal("Your soul").withColor(0x55FFFF),
					Component.literal("Your ").withColor(0xAAAAAA)
					.append(Component.literal("Paths").withStyle(style -> style.withItalic(true)))
					.append(Component.literal(" will open from here..."))), java.util.Optional.empty(), mouseX, mouseY);
		}
		// The Soul Point counter: free points, with a small soul beside them.
		int free = SoulNexus.free(data);
		String count = Integer.toString(free);
		int counterW = 12 + this.font.width(count);
		int counterX = cx - counterW / 2;
		int counterY = top + 190;
		// The small soul is centered on the number's height.
		drawOrb(g, counterX + 4, counterY + 3, 4, 0xFF55FFFF);
		drawOrb(g, counterX + 4, counterY + 3, 2, 0xFFCCFFFF);
		g.text(this.font, Component.literal(count).withColor(free > 0 ? 0x55FFFF : 0xAAAAAA), counterX + 12, counterY, WHITE, false);
		if (mouseX >= counterX - 2 && mouseX < counterX + counterW + 2 && mouseY >= counterY - 2 && mouseY < counterY + 10) {
			g.setTooltipForNextFrame(this.font, List.of(Component.literal("Gain a ").withColor(0xFFFFFF)
					.append(Component.literal("Soul Point").withColor(0x55FFFF))
					.append(Component.literal(" for every new boss you hunt!").withColor(0xFFFFFF))), java.util.Optional.empty(), mouseX, mouseY);
		}
	}

	private boolean shiftHeld;

	/** Holding Shift (10 points per click) plays a soft menu click. */
	@Override
	public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
		if ((event.input() == InputConstants.KEY_LSHIFT || event.input() == InputConstants.KEY_RSHIFT) && !shiftHeld) {
			shiftHeld = true;
			this.minecraft.getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(
					net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK, 1.6F));
		}
		return super.keyPressed(event);
	}

	@Override
	public boolean keyReleased(net.minecraft.client.input.KeyEvent event) {
		if (event.input() == InputConstants.KEY_LSHIFT || event.input() == InputConstants.KEY_RSHIFT) {
			shiftHeld = false;
		}
		return super.keyReleased(event);
	}

	private static String effect(int i, int points) {
		return switch (i) {
			case 0 -> "+" + points / 2 + " max health";
			case 1 -> "-" + trim(points * 0.25) + "% damage taken";
			default -> "+" + trim(points * 0.5) + "% damage";
		};
	}

	private static String trim(double value) {
		return value == Math.floor(value) ? Integer.toString((int) value) : Double.toString(value);
	}

	/** A filled circle of the given radius, row by row. */
	private static void drawOrb(GuiGraphicsExtractor g, int x, int y, int r, int color) {
		for (int dy = -r; dy <= r; dy++) {
			int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.5));
			g.fill(x - dx, y + dy, x + dx + 1, y + dy + 1, color);
		}
	}

	/** A line of small squares from a to b. */
	private static void line(GuiGraphicsExtractor g, double[] a, double[] b, int color, int size) {
		double dx = b[0] - a[0];
		double dy = b[1] - a[1];
		int steps = Math.max(1, (int) Math.ceil(Math.hypot(dx, dy)));
		for (int s = 0; s <= steps; s++) {
			int x = (int) Math.round(a[0] + dx * s / steps);
			int y = (int) Math.round(a[1] + dy * s / steps);
			g.fill(x, y, x + size, y + size, color);
		}
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (event.button() == InputConstants.MOUSE_BUTTON_LEFT && overSoul(event.x(), event.y())) {
			this.minecraft.getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(
					net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK, 1.0F));
			this.minecraft.gui.setScreen(new PathSelectScreen(this));
			return true;
		}
		// Same as the Paths: attack (left-click) adds, use (right-click) takes back.
		boolean add = this.minecraft.options.keyAttack.matchesMouse(event);
		boolean take = this.minecraft.options.keyUse.matchesMouse(event);
		if (add || take) {
			int amount = (event.modifiers() & InputConstants.MOD_SHIFT) != 0 ? 10 : 1;
			for (int i = 0; i < 3; i++) {
				if (inside(box(i), event.x(), event.y())) {
					ClientPlayNetworking.send(new HuntPayloads.Action("nexus", CORNERS[i], add ? amount : -amount));
					return true;
				}
			}
		}
		return super.mouseClicked(event, doubleClick);
	}
}
