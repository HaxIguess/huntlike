package com.huntlike.hunt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.util.random.Weighted;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.MobSpawnSettings;

import com.huntlike.hunt.HuntData.Quest;
import com.huntlike.hunt.HuntDefs.Hunt;

/** Draws the Hunt's animal spirits to a questing player: new animals keep appearing nearby. */
public final class SpiritLure {
	private SpiritLure() {
	}

	public static final String LURED_TAG = "huntlike_lured";
	public static final int CAP = 6;
	/** Ticks an untouched lured animal stays: one minute. */
	private static final int LURED_LIFETIME = 20 * 60;
	public static final double CAP_RADIUS = 48.0;
	private static final int HINT_DELAY = 20 * 30;

	/** Lured spawns since the quota last moved; capped so animals don't pile up forever. */
	public static final int SPAWNS_PER_KILL = 3;
	private static final Map<UUID, Integer> SPAWNS_SINCE_KILL = new HashMap<>();
	private static final Map<UUID, Integer> TIMERS = new HashMap<>();
	private static final Map<UUID, String> HINT_PLACE = new HashMap<>();
	private static final Map<UUID, Integer> HINT_TICKS = new HashMap<>();
	private static final Map<UUID, Set<String>> HINTS_SHOWN = new HashMap<>();

	public static boolean isLured(Entity entity) {
		return entity.entityTags().contains(LURED_TAG);
	}

	public static UUID ownerOf(Entity entity) {
		return BossController.ownerOf(entity);
	}

	public static boolean isLuredBy(Entity entity, ServerPlayer player) {
		return isLured(entity) && player.getUUID().equals(ownerOf(entity));
	}

	public static void reset(ServerPlayer player) {
		TIMERS.put(player.getUUID(), 0);
		SPAWNS_SINCE_KILL.put(player.getUUID(), 0);
	}

	/**
	 * A fresh start for the lure (after a Rogue Hunter dies or leaves): lured mobs still alive stop counting as lured, and
	 * the lure is back at 0 of its 3 spawns.
	 */
	public static void release(ServerPlayer player) {
		for (Mob mob : player.level().getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(256.0), m -> isLuredBy(m, player))) {
			mob.removeTag(LURED_TAG);
		}
		reset(player);
	}

	/** Lured spawns since the quota last moved (0 to 3). */
	public static int spawnsSinceKill(ServerPlayer player) {
		return SPAWNS_SINCE_KILL.getOrDefault(player.getUUID(), 0);
	}

	/** Sets that count (for the tests). */
	public static void setSpawnsSinceKill(ServerPlayer player, int spawns) {
		SPAWNS_SINCE_KILL.put(player.getUUID(), spawns);
	}

	/** A kill counted toward the quota: the lure may spawn again. */
	public static void onQuotaKill(ServerPlayer player) {
		SPAWNS_SINCE_KILL.put(player.getUUID(), 0);
	}

	public static void forget(ServerPlayer player) {
		TIMERS.remove(player.getUUID());
		SPAWNS_SINCE_KILL.remove(player.getUUID());
		HINT_PLACE.remove(player.getUUID());
		HINT_TICKS.remove(player.getUUID());
	}

	/** Removes this player's lured animals. */
	public static void cleanup(ServerPlayer player) {
		ServerLevel level = player.level();
		for (Mob mob : level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(256.0), m -> isLuredBy(m, player))) {
			mob.discard();
		}
	}

	/**
	 * Quota mobs the Spirit Lure can bring here. Animal: the biome's quota animals (Overworld only). Cluster: slimes in the
	 * Overworld, magma cubes in the Nether.
	 */
	public static List<EntityType<?>> huntableHere(ServerPlayer player, Hunt hunt) {
		if (com.huntlike.interlude.InterludeDefs.isInterlude(hunt)) {
			// Interludes lure both: the Animal Hunt's animals and the Cluster Hunt's slimes or magma cubes.
			List<EntityType<?>> both = new ArrayList<>(huntableHere(player, HuntDefs.ANIMAL));
			both.addAll(huntableHere(player, HuntDefs.CLUSTER));
			return both;
		}
		if (HuntDefs.isCluster(hunt)) {
			return clusterTypes(player.level());
		}
		List<EntityType<?>> types = new ArrayList<>();
		for (Weighted<MobSpawnSettings.SpawnerData> entry : spawnList(player.level(), player.blockPosition())) {
			types.add(entry.value().type());
		}
		return types;
	}

	/** Slimes are only lured in land biomes: no oceans or rivers. */
	private static boolean solidBiome(ServerLevel level, BlockPos pos) {
		var biome = level.getBiome(pos);
		return !biome.is(net.minecraft.tags.BiomeTags.IS_OCEAN) && !biome.is(net.minecraft.tags.BiomeTags.IS_DEEP_OCEAN)
				&& !biome.is(net.minecraft.tags.BiomeTags.IS_RIVER);
	}

	/** A dry spot standing on a solid block (no water, lava or leaves underneath). */
	private static boolean solidGround(ServerLevel level, BlockPos pos) {
		BlockPos below = pos.below();
		return level.getFluidState(pos).isEmpty() && level.getFluidState(below).isEmpty()
				&& level.getBlockState(below).isFaceSturdy(level, below, net.minecraft.core.Direction.UP);
	}

	private static List<EntityType<?>> clusterTypes(ServerLevel level) {
		if (level.dimension() == Level.OVERWORLD) {
			return List.of(net.minecraft.world.entity.EntityTypes.SLIME);
		}
		if (level.dimension() == Level.NETHER) {
			return List.of(net.minecraft.world.entity.EntityTypes.MAGMA_CUBE);
		}
		return List.of();
	}

	private static List<Weighted<MobSpawnSettings.SpawnerData>> spawnList(ServerLevel level, BlockPos pos) {
		List<Weighted<MobSpawnSettings.SpawnerData>> list = new ArrayList<>();
		if (level.dimension() != Level.OVERWORLD) {
			return list;
		}
		for (Weighted<MobSpawnSettings.SpawnerData> entry : level.getChunkSource().getGenerator()
				.getMobsAt(level, level.structureManager(), MobCategory.CREATURE, pos).unwrap()) {
			if (entry.value().type().builtInRegistryHolder().is(QuestManager.QUOTA_ANIMALS)) {
				list.add(entry);
			}
		}
		return list;
	}

	public static void tick(ServerPlayer player, HuntData data, Quest quest) {
		ServerLevel level = player.level();
		Hunt hunt = HuntDefs.hunt(quest.hunt);
		UUID id = player.getUUID();
		boolean interlude = com.huntlike.interlude.InterludeDefs.isInterlude(hunt);
		boolean overworld = level.dimension() == Level.OVERWORLD;
		List<EntityType<?>> clusterHere = clusterTypes(level);
		boolean clusterOk = !clusterHere.isEmpty() && !(overworld && !solidBiome(level, player.blockPosition()));
		boolean animalOk = overworld && !spawnList(level, player.blockPosition()).isEmpty();
		// Which kind this spawn tries: the Hunt's own, or for an Interlude a random one of the two (the other if it can't).
		boolean cluster = interlude ? (clusterOk && (!animalOk || player.getRandom().nextBoolean())) : HuntDefs.isCluster(hunt);
		boolean dimensionOk = interlude ? !clusterHere.isEmpty() || overworld : cluster ? !clusterHere.isEmpty() : overworld;
		boolean nothingHere = interlude ? !clusterOk && !animalOk : cluster ? !clusterOk : !animalOk;

		// No-spirits hint: once per biome or dimension, after 30 seconds there.
		if (!dimensionOk || nothingHere) {
			String place = dimensionOk ? "biome:" + level.getBiome(player.blockPosition()).getRegisteredName()
					: "dimension:" + level.dimension().identifier();
			if (!place.equals(HINT_PLACE.get(id))) {
				HINT_PLACE.put(id, place);
				HINT_TICKS.put(id, 0);
			}
			int ticks = HINT_TICKS.merge(id, 1, Integer::sum);
			Set<String> shown = HINTS_SHOWN.computeIfAbsent(id, k -> new HashSet<>());
			if (ticks >= HINT_DELAY && shown.add(place)) {
				player.sendSystemMessage(dimensionOk ? Messages.noSpiritsBiome(hunt) : Messages.noSpiritsDimension(hunt));
				QuestManager.playSound(player, SoundEvents.AMETHYST_BLOCK_CHIME, 0.5F);
			}
		} else {
			HINT_PLACE.remove(id);
		}

		// Lured animals nobody has touched for a minute fade away.
		if (level.getGameTime() % 20 == 0) {
			for (Mob mob : level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(128.0), m -> isLuredBy(m, player))) {
				if (mob.tickCount > LURED_LIFETIME && mob.getLastHurtByMob() == null) {
					level.sendParticles(net.minecraft.core.particles.ParticleTypes.POOF, mob.getX(), mob.getY() + 0.5, mob.getZ(), 10,
							0.3, 0.3, 0.3, 0.02);
					mob.discard();
				}
			}
		}

		int rank = data.progress(interlude ? "animal" : quest.hunt).rank();
		// 10 seconds, one second less at Ranks II, IV, VI, VIII and X.
		int interval = (10 - rank / 2) * 20;
		int timer = TIMERS.merge(id, 1, Integer::sum);
		if (timer < interval) {
			return;
		}
		TIMERS.put(id, 0);
		if (!dimensionOk || interlude && nothingHere || SPAWNS_SINCE_KILL.getOrDefault(id, 0) >= SPAWNS_PER_KILL) {
			return;
		}
		int nearby = level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(CAP_RADIUS), m -> isLuredBy(m, player)).size();
		if (nearby >= CAP) {
			return;
		}
		RandomSource random = player.getRandom();
		for (int attempt = 0; attempt < 16; attempt++) {
			double angle = random.nextDouble() * Math.PI * 2.0;
			double distance = 16.0 + random.nextDouble() * 16.0;
			int x = (int) Math.floor(player.getX() + Math.cos(angle) * distance);
			int z = (int) Math.floor(player.getZ() + Math.sin(angle) * distance);
			BlockPos column = new BlockPos(x, player.blockPosition().getY(), z);
			if (!level.isLoaded(column)) {
				continue;
			}
			if (cluster) {
				// Slimes and magma cubes come no matter the light, biome or slime chunk: any standing spot will do.
				EntityType<?> type = clusterHere.get(0);
				BlockPos pos = overworld ? level.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
						column) : QuestManager.findGround(level, column);
				if (pos == null || (overworld && !solidBiome(level, pos)) || !solidGround(level, pos)
						|| !level.noCollision(type.getSpawnAABB(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5))) {
					continue;
				}
				Entity entity = type.spawn(level, pos, EntitySpawnReason.NATURAL);
				if (entity == null) {
					continue;
				}
				lured(player, interlude ? HuntDefs.CLUSTER : hunt, entity);
				return;
			}
			List<Weighted<MobSpawnSettings.SpawnerData>> options = spawnList(level, column);
			if (options.isEmpty()) {
				continue;
			}
			EntityType<?> type = pick(options, random);
			BlockPos pos = level.getHeightmapPos(SpawnPlacements.getHeightmapType(type), column);
			if (!SpawnPlacements.isSpawnPositionOk(type, level, pos)
					|| !SpawnPlacements.checkSpawnRules(type, level, EntitySpawnReason.NATURAL, pos, random)
					|| !level.noCollision(type.getSpawnAABB(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5))) {
				continue;
			}
			Entity entity = type.spawn(level, pos, EntitySpawnReason.NATURAL);
			if (entity == null) {
				continue;
			}
			if (entity instanceof Mob mob) {
				mob.setBaby(false);
			}
			lured(player, interlude ? HuntDefs.ANIMAL : hunt, entity);
			return;
		}
	}

	/** Marks a freshly lured mob: glowing, tagged to its owner, announced. */
	private static void lured(ServerPlayer player, Hunt hunt, Entity entity) {
		ServerLevel level = player.level();
		UUID id = player.getUUID();
		entity.addTag(LURED_TAG);
		if (entity instanceof Mob glowing) {
			glowing.addEffect(new MobEffectInstance(MobEffects.GLOWING, 20 * 5, 0, false, false));
		}
		// Spiritual animals: the hunter sees them outlined in light blue.
		if (hunt == HuntDefs.ANIMAL) {
			net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(player,
					new com.huntlike.network.HuntPayloads.Highlight(entity.getId(), 20 * 5));
		}
		SPAWNS_SINCE_KILL.merge(id, 1, Integer::sum);
		entity.addTag(BossController.OWNER_PREFIX + id);
		level.sendParticles(new DustParticleOptions(hunt.color(), 1.5F), entity.getX(), entity.getY() + 0.5, entity.getZ(),
				20, 0.4, 0.5, 0.4, 0.0);
		player.sendSystemMessage(Messages.spiritLure(hunt));
		QuestManager.playSound(player, SoundEvents.AMETHYST_BLOCK_CHIME, 1.8F);
	}

	private static EntityType<?> pick(List<Weighted<MobSpawnSettings.SpawnerData>> options, RandomSource random) {
		int total = 0;
		for (Weighted<MobSpawnSettings.SpawnerData> entry : options) {
			total += Math.max(1, entry.weight());
		}
		int roll = random.nextInt(total);
		for (Weighted<MobSpawnSettings.SpawnerData> entry : options) {
			roll -= Math.max(1, entry.weight());
			if (roll < 0) {
				return entry.value().type();
			}
		}
		return options.get(0).value().type();
	}
}
